package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.service.Service;
import com.capgemini.service.ServiceImpl;

public class Main {
	private static Service service = new ServiceImpl();
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args){
		int i=0;
		do{
			System.out.println("enter the choice \n1. create account \n2.show balance \n3.deposit\n4.withdrawl\n5.fund transfer\n6.Transaction");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				service.createAccount();
				break;
			case 2:
				System.out.println();service.showBalance();
				break;
			case 3:
				service.deposit();
				break;
			case 4:
				service.withDraw();
				break;
			case 5:
				service.fundTransfer();
				break;
			case 6:
				List<String> l1 = new ArrayList<String>();
				l1=service.printTrans();
				Iterator<String> itr = l1.iterator();
				while(itr.hasNext())
				{
					System.out.println(itr.next());
				}
			default:
	
			}
			System.out.println("Do you Want to continue :1.CONTINUE \t END");
			i=sc.nextInt();
			
		}
		while(i==1);
		{
			
		}

}
}
