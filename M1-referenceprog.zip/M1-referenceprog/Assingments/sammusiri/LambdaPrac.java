package demo;

interface Dove{
	int Sum(int x,int y);
}

interface Third{
	int con(int u,int v);
}
interface vo{
	void gun();
}

interface Demo{
	String g();
}
interface arg{
	int home(String su);
	
}
interface ar{
	int sweet(String d);
}
public class LambdaPrac {
	public static void main(String args[]) {
		
		Demo r=()->"hello";
		String d=r.g();
		System.out.println(d);
		
		vo q=()->{int i=108;
		System.out.println(i);};
		q.gun();
		
		
		arg n=(str)->str.length();
		int ro=n.home("hello");
		System.out.println(ro);
		
		ar g=str->str.length();
		int var=g.sweet("the");
		System.out.println(var);
		
		
		Third f=(i,j)->{
			int min=i>j?j:i; 
		return min;
		};
		int g1=f.con(23, 10);
		System.out.println(g1);
		
		
		Dove c=(s,b)->s+b;
		int a=c.Sum(2,3);
		System.out.println(a);
		
	}

}

