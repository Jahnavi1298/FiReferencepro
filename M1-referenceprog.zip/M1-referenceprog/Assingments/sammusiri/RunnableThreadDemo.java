package demo;
            

public class RunnableThreadDemo implements Runnable{
	public RunnableThreadDemo(String name)
	{
		Thread t=new Thread(this);
		t.setName(name);
		t.start();
	}
@Override
	public void run() {
		System.out.println("Run");
		for(int i=0;i<5;i++) 
		{
			System.out.println(Thread.currentThread().getName()+i);
			//System.out.println(t.getName()+i);
			//Thread.currentThread().getName();
		//Thread t=	Thread.currentThread();
			//t.getName();
			
}
		
	}
	public static void main(String args[]) {
		Thread t=new Thread(/*rtd*/);
		RunnableThreadDemo rtd=new RunnableThreadDemo(/*t*/"hello");
		//RunnableThreadDemo rtd1=new RunnableThreadDemo(/*t*/"hey");//to run the run method written above
		//give t for the constrctor above
		//without rtd it will run run method of runnable class
		//t.start();
		//thread class has a constructor that accepts runnable obj
	}
}
