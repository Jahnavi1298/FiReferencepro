package demo;
class Employee{
	int empID;
	String name;
	Employee(int empID,String name){
		this.empID=empID;
		this.name=name;
	}
	public String toString() {
		return empID+":"+name;
	}
}
class SalariedEmp{
	Employee e;
	SalariedEmp(Employee emp){
		e=emp;
	}
	Employee getEmployee() {
		return e;
	}
}

public class Test {
public static void main(String args[]) {
	int empno=10;
	String tname="rose";
	Employee obj=new Employee(empno,tname);
	SalariedEmp ob=new SalariedEmp(obj);
	System.out.println(ob.getEmployee());
	//Employee s=ob.getEmployee();
	//System.out.println(s);
}

}
