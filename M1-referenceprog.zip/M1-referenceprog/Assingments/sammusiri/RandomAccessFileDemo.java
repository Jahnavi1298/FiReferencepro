package demo;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileDemo {
	public void readRAF() throws IOException{
		try {
			RandomAccessFile rafObj=new RandomAccessFile("C:\\Users\\rosbalaj\\Desktop\\roshni\\read.txt","r");
			String a;
			while((a=rafObj.readLine())!=null) {
System.out.println(a);
}
			rafObj.close();
}
		catch(Exception e) {
	System.out.println(e);
}
}
	public void writeRAF()throws IOException{
		try {
			RandomAccessFile rafObj=new RandomAccessFile("C:\\Users\\rosbalaj\\Desktop\\roshni\\write.txt","rw");
			rafObj.writeChars("hello");
			rafObj.close();
			
		}catch(Exception e) {
			System.out.println(e);
		}
}
	public static void main(String args[])throws IOException{
		RandomAccessFileDemo rafObj=new RandomAccessFileDemo();
		rafObj.readRAF();
		rafObj.writeRAF();
		
	}
}