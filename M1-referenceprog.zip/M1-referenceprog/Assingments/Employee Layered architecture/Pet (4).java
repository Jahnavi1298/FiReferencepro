package com.service;

public interface Pet {
 public void storeInService();
}
