package com.ui;
import java.util.*;
import com.bean.*;
import com.service.*;

public class EmployeeDetailsInput {
	Scanner sc=new Scanner(System.in);
	static Service empsrObj= new Service();
	public void takeDetails() {
		
	
	
	System.out.println("Enter Your ID:");
	int empid=sc.nextInt();
	
	
		System.out.println("Enter Your name:");
		String name=sc.next();
	
	
	
	System.out.println("Enter Your salary:");
	int sal=sc.nextInt();
	System.out.println("Enter Your Role/Designation:");
	
	String des=sc.next();
	String scheme=null;
	
	
		Employee empObj= new Employee(empid,name,sal,des,scheme);
	
	
	empsrObj.storeInService(empObj);
	}

	
	void Print() {
		
	}
	 public void displayDeatils() {

		 System.out.println("Data Stored!");
			}
		
	 }
