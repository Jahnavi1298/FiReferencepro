package com.cg.mm.service;

import java.util.Map;

import com.cg.mm.dto.Product;
import com.cg.mm.exception.PMSException;

public interface IProductService {

	void validateName(String productName)  throws PMSException;

	void validateCost(int cost) throws PMSException;

	void validateGroup(String group) throws PMSException;

	int addProduct(Product product) throws PMSException;

	Product validateId(int productId) throws PMSException;

	Map<Integer, Product> getAllProduct();

	Product deleteProduct(int productDeleteId) throws PMSException;


	
	
	

}
