package com.cg.mm.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.mm.dao.IProductDao;
import com.cg.mm.dao.ProductDaoImpl;
import com.cg.mm.dto.Product;
import com.cg.mm.exception.PMSException;

public class ProductServiceImp implements IProductService {

	IProductDao dao=new ProductDaoImpl();
	
	
	@Override
	public void validateName(String productName) throws PMSException {
		
		String nameRegEx="[a-zA-Z]{3,9}";
		
		if(!Pattern.matches(nameRegEx,productName)) {
			
			throw new PMSException("name should be alphabet and min length should be 3 letters");
		}

	}

	@Override
	public void validateCost(int cost) throws PMSException {
		
		if(cost<100) {
			
			throw new PMSException("Cost should be greater than or equal to  100");
		}
		
	}

	@Override
	public void validateGroup(String group) throws PMSException {
		
		String nameRegEx="[a-zA-Z]{4,9}";

		if(!Pattern.matches(nameRegEx,group)) {
			
			throw new PMSException("group name should be 4 to 9 letters only");
		}
		
		
	}

	@Override
	public int addProduct(Product product) throws PMSException {
		
		return dao.AddProduct(product);
	}

	@Override
	public Product validateId(int productId) throws PMSException {
		
		return dao.searchProduct(productId);
	}

	@Override
	public Map<Integer, Product> getAllProduct() {
		
		return dao.getAll();
	}

	@Override
	public Product deleteProduct(int productDeleteId) throws PMSException {
		
		return dao.deleteProduct(productDeleteId);
	}

	
	
	
	
	

}
