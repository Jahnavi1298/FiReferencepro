package com.cg.mm.dao;

import java.util.Map;

import com.cg.mm.dto.Product;
import com.cg.mm.exception.PMSException;

public interface IProductDao {
	
	Map<Integer,Product> getAll();
	int AddProduct(Product product) throws PMSException;
	Product searchProduct(int productId) throws PMSException;
	Product deleteProduct(int productDeleteId) throws PMSException;
	
	

}
