package com.cg.mm.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mm.dto.Product;
import com.cg.mm.exception.PMSException;
import com.cg.mm.utility.PMUtility;

public class ProductDaoImpl implements IProductDao{
	
	
	//PMUtility utility=new PMUtility();

	@Override
	public Map<Integer, Product> getAll(){
		
		
		
		return PMUtility.getHm1();
	}

	@Override
	public int AddProduct(Product product) throws PMSException {
		
		int id=(int) (Math.random()*1000+1);
		
		product.setId(id);
		
		Map<Integer,Product> hm2=PMUtility.getHm1();
		hm2.put(product.getId(),product);
		PMUtility.setHm1(hm2);
		
		return id;
	}

	@Override
	public Product searchProduct(int productId) throws PMSException {

		Map<Integer,Product> map=PMUtility.getHm1();
		List<Product> list=new ArrayList<Product>(map.values());
		Product productobj=null;
		boolean flag=false;
		
		for (Product product : list) {
			if (product.getId() == productId) {
				productobj = product;
				flag = true;
				break;
			}
		
	}
	
		if(!flag) {
			throw new PMSException("Product is not present with given id");
		}
		
		return productobj;
	
	
	
	}

	@Override
	public Product deleteProduct(int productDeleteId) throws PMSException {
		
		Map<Integer,Product> map=PMUtility.getHm1();
		List<Product> list=new ArrayList<Product>(map.values());
		Product productobj=null;
		boolean flag=false;
		
		for (Product product : list) {
			if (product.getId() == productDeleteId) {
				productobj = product;
				flag = true;
				map.remove( productDeleteId);
				break;
			}
		
	}
		
	
		if(!flag) {
			throw new PMSException("Product is not present with given id");
		}
		
		return productobj;
	
	}
}
