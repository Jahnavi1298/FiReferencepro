package UI;


import java.util.Map;
import java.util.Scanner;

import MobileBeans.CustomerBeans;
import MobileBeans.MobileBean;
import MobileBeans.Reciept;
import MobileService.MobileServiceClass;

public class MobileMainClass {

	
	public static void main(String[] args) {
		
		MobileServiceClass MS=new MobileServiceClass();
		while(true)
		{
		
		System.out.println("Choose The  Option");
		System.out.println("1.Place Order For Mobile");
		System.out.println("2.Your Orders Detail");
		Scanner sc=new Scanner(System.in);
		
		int n=sc.nextInt();
		
		switch (n) {
		case 1:
			MS.purchaseMobile();
		break;
		
		case 2:
			System.out.println("Enter Your order ID for your Bill Detail");
			int orderid=sc.nextInt();
				
			Reciept rpc1=MS.getOrderdetails(orderid);
				System.out.println(rpc1);
				
			break;
			
	 
		}
	}
}
}
