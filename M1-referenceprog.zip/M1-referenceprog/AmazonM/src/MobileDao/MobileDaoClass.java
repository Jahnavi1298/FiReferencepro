package MobileDao;



import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



import MobileBeans.CustomerBeans;
import MobileBeans.MobileBean;
import MobileBeans.Reciept;


public class MobileDaoClass {
	
	//Map<Integer, CustomerBeans> hm=new HashMap<Integer, CustomerBeans>();
	Map<Integer, MobileBean> hm1=new HashMap<Integer, MobileBean>();
	Map<Integer, Reciept> hm2=new HashMap<Integer, Reciept>();

	Reciept rp=new Reciept();
	public MobileDaoClass()
	{
		hm1.put(101, new MobileBean(101,"samsung",10000)); 
		hm1.put(202, new MobileBean(202,"Gionee",20000)); 
		hm1.put(303, new MobileBean(303,"MI",15000)); 
		hm1.put(404, new MobileBean(404,"samsung",17000)); 
		hm1.put(505, new MobileBean(505,"Vivo",14000)); 
		hm1.put(606, new MobileBean(606,"Htc",9000)); 
	}
	public  void storeIntoDao(Reciept rp)
	{
		
		hm2.put(rp.getOrderId(),rp);
		
		
	}
	
	
	public Reciept getFromDao(int orderid) {
		
		return hm2.get(orderid);
	}


	public void displayMobiles() {
		
		
		for(Integer aKey : hm1.keySet())
		{
				MobileBean aValue = hm1.get(aKey);
				System.out.println(aValue);	
		}
		
	}
	
	public MobileBean GetMobiledetail(int n) 
	{
	
		return hm1.get(n);
	}
	


}
