package MobileService;

public interface MobileServiceInterface {

}
