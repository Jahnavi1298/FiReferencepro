package MobileBeans;

import java.util.Date;

public class CustomerBeans {
	
	private String customerName;
	private String CustAddrs;
	private String CustMoNo;
	private int CustId;
	private Date Date;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustAddrs() {
		return CustAddrs;
	}
	public void setCustAddrs(String custAddrs) {
		CustAddrs = custAddrs;
	}
	public String getCustMoNo() {
		return CustMoNo;
	}
	public void setCustMoNo(String custMoNo) {
		CustMoNo = custMoNo;
	}

	public Date getDate() {
		return Date;
	}
	public void setDate(Date d) {
		Date = d;
	}
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	@Override
	public String toString() {
		return "CustomerBeans [customerName=" + customerName + ", CustAddrs=" + CustAddrs + ", CustMoNo=" + CustMoNo
				+ ", CustId=" + CustId + ", Date=" + Date + "]";
	}

	
	
	

}
