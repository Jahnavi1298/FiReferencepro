package com.capgemini.dao;

import com.capgemini.model.Product;

public interface OrderDao {
	int saveOrder(Product pro);

	}
