package com.capgemini.service;

import com.capgemini.model.Product;

public interface OrderService {

	int calculateOrder(Product p);

	}


