package com.capgemini.validations;

public class Validation {
	public boolean name(String str){
		boolean name_val = str.matches("[A-Z][a-z]");
		if(name_val)
		return true;
		return false;
		
	}

}
