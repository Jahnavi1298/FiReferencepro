package com.cg.empapp.service;



public class EmployeeServiceImpl implements EmployeeService
{
	
	
}